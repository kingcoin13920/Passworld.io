import PassworldModule from './passworld-module';

export default function Home() {
  return (
    <main className="min-h-screen">
      <PassworldModule />
    </main>
  );
}
